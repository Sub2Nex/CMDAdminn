workspace.CurrentCamera.CameraSubject = script:WaitForChild("Object").Value
script:Destroy()
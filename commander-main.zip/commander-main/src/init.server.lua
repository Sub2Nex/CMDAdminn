-- you do not need to touch this script, it is only a loader to load Commander
require(script.MainModule)(script.Settings, script.Packages, script.Stylesheets)